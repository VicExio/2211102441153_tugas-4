import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class No1 extends No
{
    void cetakbaru(){
        No1 no1 = new No1();
        getWorld().addObject(no1,Greenfoot.getRandomNumber(300),0);
    }
    void maju(){
        setLocation(getX(), getY()+4);
    }
    public void act(){
        super.act();
    }
}
