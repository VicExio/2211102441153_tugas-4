import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


public class kodok extends Actor
{
    int count=0;
    
    void dimakan(){
        Counter.add(1);
        
        getWorld().removeObject(this);
    }
    public void act() 
    {
        if(Greenfoot.isKeyDown("right")){
            setLocation(getX()+2, getY());
       }
       else if(Greenfoot.isKeyDown("left")){
           setLocation(getX()-2, getY()); 
       }
       if(isTouching(No.class)){
           Counter2.add(-1);
           dimakan();
       }
       if(Counter2.value==0){
           Greenfoot.delay(1);
           Greenfoot.setWorld(new Endpage());
           getWorld().removeObject(this);
        }
    }    
}
