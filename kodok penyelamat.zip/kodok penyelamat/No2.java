import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class No2 extends No
{
    void cetakbaru(){
        No2 no2 = new No2();
        getWorld().addObject(no2,Greenfoot.getRandomNumber(300),0);
    }
    void maju(){
        setLocation(getX(), getY()+5);
    }
    public void act(){
        super.act();
    }
}
