import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Candy2 extends Candy
{
    void cetakbaru(){
        Candy2 candy2 = new Candy2();
        getWorld().addObject(candy2,Greenfoot.getRandomNumber(300),0);
    }
    void maju(){
        setLocation(getX(), getY()+6);
    } 
    public void act(){
        super.act();
    }    
}
