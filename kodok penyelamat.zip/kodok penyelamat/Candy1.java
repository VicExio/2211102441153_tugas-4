import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


public class Candy1 extends Candy
{

    void cetakbaru(){
        Candy1 candy1 = new Candy1();
        getWorld().addObject(candy1,Greenfoot.getRandomNumber(300),0);
    }
    void maju(){
        setLocation(getX(), getY()+3);
    } 
    public void act(){
        super.act();
    }    
}
