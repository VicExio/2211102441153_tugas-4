import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


public class Candy4 extends Candy
{
    void cetakbaru(){
        Candy4 candy4 = new Candy4();
        getWorld().addObject(candy4,Greenfoot.getRandomNumber(300),0);
    }
    void maju(){
        setLocation(getX(), getY()+3);
    } 
    public void act(){
        super.act();
    }    
}
